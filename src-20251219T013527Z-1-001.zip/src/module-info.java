module snakeGame {
	requires java.desktop;
}